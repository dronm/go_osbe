package srv

const (
	ER_ACCESS_DENIED = "Доступ запрещен"
)
