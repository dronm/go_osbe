package httpSrv

import (
	"net/http"
	"net/url"
	"strings"
	"fmt"
	"time"
	"encoding/json"
	"os"
	
	"osbe/srv"
	"osbe/socket"
	"osbe/view"
	//"osbe/tokenBlock"	
	"osbe/stat"	
)

//HTTP server, OnHandleRequest, must be defined

const (
	PARAM_TOKEN = "token"
	
	PARAM_CONTROLLER = "c"
	PARAM_METH = "f"
	PARAM_VIEW = "v"
	PARAM_VIEW_TMPL = "t" //view template to send with response, added in http_app
	PARAM_QUERY_ID = "query_id"
	
	PARAM_TRANSFORM_TMPL = "templ" //transformation template
	
	CONTROLLER_QUERY_POSF = "_Controller"
	
	DEF_USER_TRANSFORM_CLASS_ID =  "ViewBase"
	DEF_GUEST_TRANSFORM_CLASS_ID =  "Login"
)

type requestHandlerProto = func(w http.ResponseWriter, r *http.Request)
type OnBeforeHandleRequestProto func(socket.ClientSocketer)

type methodParams struct {
	Argv map[string]string `json:"argv"`
}

type HTTPServer struct {
	srv.BaseServer
	Statistics stat.SrvStater
	
	OnBeforeHandleRequest OnBeforeHandleRequestProto
	HTTPDir string	
	AllowedExtensions []string
	Headers map[string]string
	UserTransformClassID string
	GuestTransformClassID string
	
	viewContentTypes map[string]string
}

func (s *HTTPServer) Run() {

	if s.OnHandleRequest == nil {
		s.Logger.Fatal("HTTPServer.OnHandleRequest not defined")
	}
	/*if s.OnHandlePermission != nil && s.OnHandleProhibError == nil {
		s.Logger.Fatal("HTTPServer.OnHandlePermission defined, but OnHandleProhibError not defined")
	}*/
	if s.OnHandleSession != nil && s.OnHandleServerError == nil {
		s.Logger.Fatal("HTTPServer.OnHandleSession defined, but OnHandleServerError not defined")
	}

	//TLS if nedded
	tls_start := (s.TlsAddress != "" && s.TlsCert != "" && s.TlsKey != "")
	ws_start := (s.Address!= "")
	
	http.HandleFunc("/", s.HandleRequest)
	
	s.Statistics = stat.NewSrvStat()
	
	if tls_start {
		s.Logger.Infof("Starting secured web server: %s", s.TlsAddress)		
		if !ws_start {
			//main loop
			http.ListenAndServeTLS(s.TlsAddress, s.TlsCert, s.TlsKey, nil)
		}else{
			//2 servers
			go http.ListenAndServeTLS(s.TlsAddress, s.TlsCert, s.TlsKey, nil)
		}
	}
	
	
	if ws_start {		
		s.Logger.Infof("Starting web server: %s", s.Address)		
		http.ListenAndServe(s.Address, nil)	
	}
}

//Retrieves parameter, first looks into cookies, then QueryParams
func extractParam(r *http.Request, queryParams url.Values, param string) (val string, exp time.Time) {
	//analyse cookies	
	if v_cookie, err := r.Cookie(param); v_cookie != nil && err == nil {
		val = v_cookie.Value
		exp = v_cookie.Expires
	}	
	
	//if param is not present in cookies, trying to get it from query params
	if val == "" {
		if val_par, ok := queryParams[param]; ok && len(val_par)>0 {
			val = val_par[0]
		}	
	}

	return
}

func (s *HTTPServer) checkExtension(ext string) bool {
	for _,s_ext := range s.AllowedExtensions {
		if ext == s_ext {
			return true
		}
	}
	return false
}

func (s *HTTPServer) HandleRequest(w http.ResponseWriter, r *http.Request) {
	
	var query_params url.Values
	if r.URL.Path != "/" {
		path_parts := strings.Split(r.URL.Path, "/")
	
		//query params
		file_parts := strings.Split(path_parts[len(path_parts)-1], ".")		
		n := len(file_parts)
		if n > 0 && s.checkExtension(file_parts[n-1]) && file_exists(s.HTTPDir + r.URL.Path) {
			//file serving
			http.ServeFile(w, r, s.HTTPDir + r.URL.Path)
			return
		}
		//controller/method check
		if len(path_parts) >= 2 {		
			query_params = r.URL.Query()
			query_params.Add(PARAM_CONTROLLER, path_parts[1])
			if len(path_parts) >= 3 {
				query_params.Add(PARAM_METH, path_parts[2])
			}	
			if len(path_parts) >= 4 {
				query_params.Add(PARAM_VIEW, path_parts[3])
			}
		}else{
			
			//not found
			s.Logger.Errorf("HTTPServer.OnHandleRequest %s file with extension %s not found", s.HTTPDir + r.URL.Path,file_parts[n-1])
			w.WriteHeader(http.StatusNotFound)
			//+ if ViewHTML return NotFound page???
			return
		}
		
	}else if r.Method == http.MethodGet {
		//always non-nil map
		query_params = r.URL.Query()
	}else{
		r.ParseForm()
		query_params = r.Form
	}		
	sock := NewHTTPSocket(w, r)
	sock.Token, sock.TokenExpires = extractParam(r, query_params, PARAM_TOKEN)
	token_from_query := (sock.Token != "")
	
fmt.Println("HandleRequest sock.Token from query=",sock.Token)

	//turn query/body parameters to json payload
	var query_id, view_id string	
	meth_params := methodParams{Argv: make(map[string]string)}
	
	for par_key, par_val:= range query_params {
		if par_key == PARAM_CONTROLLER && len(par_val)>0 {
			sock.ControllerID = par_val[0]
			//extract postfix if any
			posf_pos := len(sock.ControllerID)-len(CONTROLLER_QUERY_POSF)
			if posf_pos > 0 && sock.ControllerID[posf_pos:] == CONTROLLER_QUERY_POSF {
				sock.ControllerID = sock.ControllerID[:posf_pos]
			}
		
		}else if par_key == PARAM_METH && len(par_val)>0 {
			sock.MethodID = par_val[0]
			
		}else if par_key == PARAM_VIEW && len(par_val)>0 {
			sock.TransformClassID = par_val[0]
			view_id = par_val[0] 

		}else if par_key == PARAM_VIEW_TMPL && len(par_val)>0 {
			sock.ViewTemplateID = par_val[0]
			
		}else if par_key == PARAM_QUERY_ID && len(par_val)>0 {
			query_id = par_val[0]

		}else if par_key == PARAM_TRANSFORM_TMPL && len(par_val)>0 {
			sock.TransformTemplateID = par_val[0]
						
		}else if len(par_val)>0 {
			meth_params.Argv[par_key] = par_val[0]
		}
	}
	
	//session
	if s.OnHandleSession != nil {
		err := s.OnHandleSession(sock)
		if err != nil {
			s.Logger.Errorf("HTTPServer HandleRequest OnHandleSession: %v", err)
			s.OnHandleServerError(s, sock, query_id, view_id)
			return
		}
fmt.Println("HandleRequest sock.Token from session=",sock.Token)
		if sock.Token == "" {
			//new session started
			sess := sock.GetSession()
			sock.Token = sess.SessionID()
			
			s.Statistics.IncHandshakes()
		}
		
		if !token_from_query {			
			//sock.TokenExpires = sess.
			// Make sure the session cookie is not accessable via javascript.
			http.SetCookie(w, &http.Cookie{Name: PARAM_TOKEN,
					Value: sock.Token,
					HttpOnly: true,
					//Expires= sock.TokenExpires,
					//Path:
					//Domain
					//Expires
					//MaxAge
				})
		}		
	}

	if sock.TransformClassID == "" {
		//defaults
		sess := sock.GetSession()	
		if sess.GetBool("LOGGED") {
			if s.UserTransformClassID != "" {
				sock.TransformClassID = s.UserTransformClassID
			}else{
				sock.TransformClassID = DEF_USER_TRANSFORM_CLASS_ID
			}
		}else{
			if s.GuestTransformClassID != "" {
				sock.TransformClassID = s.GuestTransformClassID
			}else{
				sock.TransformClassID = DEF_GUEST_TRANSFORM_CLASS_ID
			}			
		}
	}
	view_id = sock.TransformClassID
	if !view.Registered(view_id) {
		view_id = "ViewHTML"
	}	

	if query_id =="" {
		//http always expects result
		query_id = "1"
	}

		
	argv_s, err := json.Marshal(meth_params)
	if err != nil {
		s.Logger.Errorf("HTTPServer json.Marshal: %v", err)
		s.OnHandleServerError(s, sock, query_id, view_id)
		return
	}
	
	//header
	cont_tp := s.GetViewContentType(view_id)
	if cont_tp != "" {
		w.Header().Set("Content-Type", cont_tp)
	}else{
		s.Logger.Warnf("Content type for view %s not defined", view_id)
	}
	
	if s.Headers != nil {
		for key, val := range s.Headers {
			w.Header().Set(key, val)
		}
	}
	//w.Header().Set("")
	
	if s.OnBeforeHandleRequest != nil {
		s.OnBeforeHandleRequest(sock)
	}
s.Logger.Debugf("HTTPServer calling OnHandleRequest ControllerID=%s, MethodID=%s, query_id=%s, argv_s=%s, view_id=%s", sock.ControllerID, sock.MethodID, query_id, argv_s, view_id)	
	s.OnHandleRequest(s, sock, sock.ControllerID, sock.MethodID, query_id, argv_s, view_id)
}

func (s *HTTPServer) SendToClient(sock socket.ClientSocketer, msg []byte) error {
	if http_sock, ok := sock.(*HTTPSocket); ok {
		fmt.Fprint(http_sock.Response, string(msg))
	}
	return nil
}

//empty stub, ClientSockets is not used
func (s *HTTPServer) GetClientSockets() *socket.ClientSocketList{
	return nil
}

func (s *HTTPServer) AddViewContentType(viewID, mimeType, charset string) {
	if s.viewContentTypes == nil {
		s.viewContentTypes = make(map[string]string)
	}
	s.viewContentTypes[viewID] = mimeType
	if charset != "" {
		s.viewContentTypes[viewID] += "; "+charset
	}
}

func (s *HTTPServer) GetViewContentType(viewID string) string {
	if tp, ok := s.viewContentTypes[viewID]; ok {
		return tp
	}
	return ""
}

func (s *HTTPServer) AddFile(viewID, mimeType, charset string) {
	if s.viewContentTypes == nil {
		s.viewContentTypes = make(map[string]string)
	}
	s.viewContentTypes[viewID] = mimeType
	if charset != "" {
		s.viewContentTypes[viewID] += "; "+charset
	}
}

func (s *HTTPServer) GetStatistics() stat.SrvStater {
	return s.Statistics
}

func file_exists(fileName string) bool {
	if _, err := os.Stat(fileName); err == nil || !os.IsNotExist(err) {
		return true
	}
	return false
}


