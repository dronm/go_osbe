package httpSrv

import(
	"net/http"
	"net"
	"time"
	
	"osbe/socket"
)

type HTTPSocket struct {
	socket.ClientSocket
	Response http.ResponseWriter
	Request *http.Request
	ControllerID string
	MethodID string
	TransformTemplateID string //transformation template, templ parameter
	TransformClassID string //v parameter
	ViewTemplateID string //t parameter
}

func (s *HTTPSocket) GetDescr() string {
	return ""
}

func (s *HTTPSocket) Close() {
}

func (s *HTTPSocket) GetConn() net.Conn{
	return nil
}

func (s *HTTPSocket) GetToken() string{
	return s.Token
}

func (s *HTTPSocket) GetID() string{
	return s.ID
}

func (s *HTTPSocket) GetDemandLogout() chan bool{
	return s.DemandLogout
}

func (s *HTTPSocket) UpdateLastActivity(){
	s.LastActivity = time.Now()
}

func (s *HTTPSocket) GetIP() string{
	if s.Request == nil {
		return ""
	}
	return socket.GetRemoteAddrIP(s.Request.RemoteAddr)
}

func NewHTTPSocket(w http.ResponseWriter, r *http.Request) *HTTPSocket{	
//PresetFilter: socket.NewPresetFilter()
	return &HTTPSocket{ClientSocket: socket.ClientSocket{},
			Response: w,
			Request: r,
	}
}
