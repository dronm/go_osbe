package model

const DELETED_MODEL_ID ModelID = "DeletedRows"

type Deleted_Model_row struct {
	Count int64 `json:"count"`
}

func New_Deleted_Model(cnt int64) Modeler{
	m := &Model{ID: DELETED_MODEL_ID, Rows: make([]ModelRow, 1)}
	m.Rows[0] = &Deleted_Model_row{Count: cnt}
	return m
}

