package model

//

import(
	"sync"	
	"strings"
	
	"osbe/fields"
)
//aggregation function
type AggFunction struct {	
	Alias string
	Expr string
}

//
type ModelMD struct {	
	Fields fields.FieldCollection
	ID string
	Relation string
	AggFunctions []*AggFunction
	LimitCount int
	LimitConstant string
	mx sync.RWMutex
	FieldList string
}
func (m *ModelMD) GetFields() fields.FieldCollection {
	return m.Fields
}
//fields as comma separated list for sql used in select query
func (m *ModelMD) GetFieldList() string {
	if m.FieldList == "" {
		m.mx.Lock()
		l := make([]string, len(m.Fields))
		for _, fld := range m.Fields {
			l[fld.GetOrderInList()] = fld.GetId()
		}
		m.FieldList = strings.Join(l, ",")
		m.mx.Unlock()		
	}
	return m.FieldList
}

