package osbe

import (
	"reflect"
	"fmt"
	"errors"
	"encoding/json"
	
	"osbe/fields"
	"osbe/socket"
	"osbe/srv"
	"osbe/response"
)

//public method
type PublicMethodID string
type PublicMethodCollection map[PublicMethodID] PublicMethod
type PublicMethodEventList []string

type PublicMethod interface {
	GetID() PublicMethodID
	GetFields() fields.FieldCollection
	Unmarshal(payload []byte) (reflect.Value, error)
	Run(Applicationer, srv.Server, socket.ClientSocketer, *response.Response, reflect.Value) error
	GetEventList() PublicMethodEventList
	//AddEvent(string)
}

type Base_PublicMethod struct {
	ID string
	Fields fields.FieldCollection
	EventList PublicMethodEventList
}

func (pm *Base_PublicMethod) GetID() PublicMethodID {
	return PublicMethodID(pm.ID)
}

func (pm *Base_PublicMethod) GetEventList() PublicMethodEventList {
	return pm.EventList
}

func (pm *Base_PublicMethod) AddEvent(evId string) {
	pm.EventList[len(pm.EventList)-1] = evId
}

func (pm *Base_PublicMethod) GetFields() fields.FieldCollection {
	return pm.Fields
}

type PublicMethodWithEvent interface {
	GetEventList() PublicMethodEventList
	AddEvent(string)
}

type PublicMethodError struct {
    Code int
    Err error
}
func (e PublicMethodError) Error() string {
	//e.Code
	return fmt.Sprintf("%v", e.Err)
}

func NewPublicMethodError(code int, err string) *PublicMethodError{
	return &PublicMethodError{Code: code, Err: errors.New(err)}
}

func PublishPublicMethodEvents(app Applicationer, pm PublicMethod, params map[string]interface{}) {
	on_ev := app.GetOnPublishEvent()
	if on_ev != nil {
		l := pm.GetEventList()
		if l != nil {
			params_s := "null"
			if params != nil && len(params) > 0 {				
				if par, err := json.Marshal(params); err == nil {
					params_s = string(par)
				}
			}
			for _, ev_id := range l {				
				if ev_id != "" {
					on_ev(ev_id, `"params":`+params_s)
				}
			}
		}
	}
}
