package fields

/*import (
	"encoding/json"
)*/

type Ref struct {
	Keys map[string]interface{} `json:"keys"`
	Descr string `json:"descr"`
	Data_type string `json:"data_type"`
}
/*
func (r *Ref) UnmarshalJSON(d []byte) error {
	return json.Unmarshal(d, r)
}

func (r *Ref) MarshalJSON() ([]byte, error) {
	return json.Marshal(r)
}*/
