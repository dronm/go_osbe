package osbe

import(
	"encoding/json"	
	"errors"	
	"strings"
	"reflect"
	"fmt"
)

//Command function
type ExtCommand struct {
	Func string `json:"func"` //function Controller.method
	QueryId string `json:"query_id"`
}


type Controller interface {
	//InitPublicMethods()
	GetPublicMethod(PublicMethodID) (PublicMethod, error)
	GetID() string
}

type Base_Controller struct {
	ID string
	PublicMethods PublicMethodCollection	
}
func (c *Base_Controller) GetID() string {
	return c.ID
}
func (c *Base_Controller) GetPublicMethod(publicMethodID PublicMethodID) (PublicMethod, error) {
	if pm, ok := c.PublicMethods[publicMethodID]; ok {
		return pm, nil
	}
	return nil, errors.New(fmt.Sprintf(ER_CONTOLLER_METH_NOT_DEFINED, string(publicMethodID), string(c.GetID())))
}


type ControllerCollection map[string] Controller

//parses external command from JSON string of arguments
//argument "func" at least MUST exist!
//Returns: public method interface, argv - all parsed arguments, not validated, error if any
func (c *ControllerCollection) ParseJSONCommand(payload []byte) (contr Controller, pm PublicMethod, argv reflect.Value, queryId string, err error) {

	//1) unmarshal Controller-method to base function structure		
	var cmdPayload = ExtCommand{}
	err = json.Unmarshal(payload, &cmdPayload)
	if err != nil {		
		return
	}	
	
	//func - Controller.method
	contr, pm, argv, err = c.ParseFunctionCommand(cmdPayload.Func, payload)
	queryId = cmdPayload.QueryId

	return
	
}

//parses command from function string of type ControllerID.MethodID
func (c *ControllerCollection) ParseFunctionCommand(fn string, argsPayload []byte) (contr Controller, pm PublicMethod, argv reflect.Value, err error) {
	//
	p := strings.Index(fn, ".")
	if p == -1 {
		err = errors.New(ER_PARSE_NO_METH) 
		return
	}
		
	contr, pm, argv, err = c.ParseCommand(fn[:p], fn[p+1:], argsPayload)
	return
}

//parses command from separated controller,method IDs
func (c *ControllerCollection) ParseCommand(controllerID string, methodID string, argsPayload []byte) (contr Controller, pm PublicMethod, argv reflect.Value, err error) {
	//check controller
	ok := false
	contr, ok = (*c)[controllerID]
	if !ok {
		err = errors.New(fmt.Sprintf(ER_PARSE_CTRL_NOT_DEFINED, controllerID)) 
		return
	}
	
	//check method
	pm, err = contr.GetPublicMethod(PublicMethodID(methodID))
	if err != nil {
		return
	}
	
	//unmarshal params to structure
	argv, err = pm.Unmarshal(argsPayload)
	return
}


