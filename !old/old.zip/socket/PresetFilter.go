package socket

import (	
	"osbe/sql"
)

//Individual global filter
type PresetFilter map[string]sql.FilterCondCollection

func (f *PresetFilter) Add(modelID string, conditions sql.FilterCondCollection) {
	(*f)[modelID] = conditions
}
func (f *PresetFilter) Get(modelID string) sql.FilterCondCollection {
	if v, ok := (*f)[modelID]; ok {
		return v
	}
	return nil
}

func NewPresetFilter() PresetFilter{
	return make(PresetFilter,0)
}
