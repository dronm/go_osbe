package constants

/**
 * Andrey Mikhalevich 16/12/21
 * This file is part of the OSBE framework
 */

//Controller method model
import (
	"osbe/fields"
)

type Constant_set_value_argv struct {
	Argv *Constant_set_value `json:"argv"`	
}

//
type Constant_set_value struct {
	Id fields.ValText `json:"id" required:"true"`
	Val fields.ValText `json:"val"`
}

