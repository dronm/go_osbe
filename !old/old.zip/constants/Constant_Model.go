package constants

/**
 * Andrey Mikhalevich 15/12/21
 * This file is part of the OSBE framework
 */

import (
	"osbe/fields"
)	

//Key
type Constant_keys struct {
	Id fields.ValText `json:"id"`
}

