package constants

const (
	ER_CONST_NOT_DEFINED = "Константа '%s' не определена"
)
